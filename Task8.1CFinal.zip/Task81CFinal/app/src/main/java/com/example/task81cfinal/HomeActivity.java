package com.example.task81cfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task81cfinal.data.DatabaseHelper;
import com.example.task81cfinal.model.Playlist;

public class HomeActivity extends AppCompatActivity {

    DatabaseHelper db;

    EditText videoUrl;

    Button play;
    Button addToPlaylist;
    Button myPlaylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        videoUrl = findViewById(R.id.editTextUrlLink);

        play = findViewById(R.id.buttonPlay);
        addToPlaylist = findViewById(R.id.buttonAddPlaylist);
        myPlaylist = findViewById(R.id.buttonPlaylist);

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String svideoUrl = videoUrl.getText().toString();

                Intent intentPlay = new Intent(HomeActivity.this, VideoActivity.class);
                intentPlay.putExtra("videoUrl", svideoUrl);
                startActivity(intentPlay);
            }
        });

        Intent intent = getIntent();
        Integer user_id = intent.getIntExtra("user_id", 0);

        addToPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String svideoUrl = videoUrl.getText().toString();

                long result = db.insertPlaylist(new Playlist(user_id, svideoUrl));

                if (result > 0)
                {
                    Toast.makeText(HomeActivity.this, "Success", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(HomeActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                }
            }
        });

        db = new DatabaseHelper(this);

        myPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentMyPlaylist = new Intent(HomeActivity.this, PlaylistActivity.class);
                intentMyPlaylist.putExtra("user_idSend", user_id);
                startActivity(intentMyPlaylist);
            }
        });
    }
}
