package com.example.task81cfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.task81cfinal.data.DatabaseHelper;
import com.example.task81cfinal.model.User;

public class MainActivity extends AppCompatActivity {

    EditText usernameL;
    EditText passwordL;

    Button login;
    Button signUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameL = findViewById(R.id.editTextUsernameL);
        passwordL = findViewById(R.id.editTextPasswordL);

        login = findViewById(R.id.buttonLogin);
        signUp = findViewById(R.id.buttonSignUp);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseHelper db;
                db = new DatabaseHelper(getApplicationContext());

                String susernameL = usernameL.getText().toString();
                String spasswordL = passwordL.getText().toString();

                if (susernameL.isEmpty() || spasswordL.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                }
                if (incorrectLogin(db, susernameL, spasswordL))
                {
                    return;
                }
                else
                {
                    User user = db.getUser(susernameL);
                    int userId = user.getUserId();

                    Intent intentLogin = new Intent(MainActivity.this, HomeActivity.class);
                    intentLogin.putExtra("user_id", userId);
                    startActivity(intentLogin);
                }
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentSignUp = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(intentSignUp);
            }
        });
    }

    private boolean incorrectLogin(DatabaseHelper db, String username, String password) {
        db = new DatabaseHelper(getApplicationContext());

        // check is username exists...

        // checks if password is incorrect
        if (db.fetchUser(username, password) == false) {
            Toast.makeText(MainActivity.this, "Password is Incorrect!", Toast.LENGTH_SHORT).show();
            return true;
        }

        return false;
    }
}
