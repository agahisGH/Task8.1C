package com.example.task81cfinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task81cfinal.data.DatabaseHelper;
import com.example.task81cfinal.model.Playlist;

import java.util.ArrayList;
import java.util.List;

public class PlaylistActivity extends AppCompatActivity {

    ListView playlistListView;

    ArrayList<String> playlistArrayList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        playlistListView = findViewById(R.id.listViewLinks);

        playlistArrayList = new ArrayList<>();
        DatabaseHelper db = new DatabaseHelper(PlaylistActivity.this);

        Intent intent = getIntent();
        Integer user_idReceive = intent.getIntExtra("user_idSend", 0);

        List<Playlist> playlistList = db.fetchAllPlaylists(user_idReceive);

        for (Playlist playlist: playlistList)
        {
            playlistArrayList.add("URL: " + playlist.getUrl());
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, playlistArrayList);
        playlistListView.setAdapter(adapter);
    }
}
