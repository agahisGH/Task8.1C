package com.example.task81cfinal;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.task81cfinal.data.DatabaseHelper;
import com.example.task81cfinal.model.User;

public class SignUpActivity extends AppCompatActivity {

    DatabaseHelper db;

    EditText fullNameSU;
    EditText usernameSU;
    EditText passwordSU;
    EditText confirmPasswordSU;

    Button createAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        fullNameSU = findViewById(R.id.editTextFullNameSU);
        usernameSU = findViewById(R.id.editTextUsernameSU);
        passwordSU = findViewById(R.id.editTextPasswordSU);
        confirmPasswordSU = findViewById(R.id.editTextConfirmPasswordSU);

        createAccount = findViewById(R.id.buttonCreateAccount);

        db = new DatabaseHelper(this);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sfullNameSU = fullNameSU.getText().toString();
                String susernameSU = usernameSU.getText().toString();
                String spasswordSU = passwordSU.getText().toString();
                String sconfirmPasswordSU = confirmPasswordSU.getText().toString();

                if (sfullNameSU.isEmpty() || susernameSU.isEmpty() || spasswordSU.isEmpty() || sconfirmPasswordSU.isEmpty())
                {
                    Toast.makeText(SignUpActivity.this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                }
                if (sconfirmPasswordSU.equals(spasswordSU) == false)
                {
                    Toast.makeText(SignUpActivity.this, "Please make sure passwords are the same!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    long result = db.insertUser(new User(susernameSU, spasswordSU));

                    if (result > 0) {
                        Toast.makeText(SignUpActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(SignUpActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
