package com.example.task81cfinal;

public class YoutubeConfig {

    public YoutubeConfig() {
    }

    private static final String API_KEY = "AIzaSyB5neo3ei2pBlizmdHyqgiTWedhMgvNVPQ";

    public static String getApiKey() {
        return API_KEY;
    }
}
