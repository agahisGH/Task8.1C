package com.example.task81cfinal.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.task81cfinal.model.Playlist;
import com.example.task81cfinal.model.User;
import com.example.task81cfinal.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_USER_TABLE = "CREATE TABLE " + Util.USERS_TABLE_NAME + "(" + Util.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.USERNAME + " TEXT, " + Util.PASSWORD + " TEXT)";

        String CREATE_PLAYLIST_TABLE = "CREATE TABLE " + Util.PLAYLISTS_TABLE_NAME + "(" + Util.PLAYLIST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.URL + " TEXT, " + Util.USER_ID + " TEXT)";

        sqLiteDatabase.execSQL(CREATE_USER_TABLE);
        sqLiteDatabase.execSQL(CREATE_PLAYLIST_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + Util.DATABASE_NAME;
        sqLiteDatabase.execSQL(DROP_USER_TABLE, new String[]{Util.USERS_TABLE_NAME});

        String DROP_PLAYLIST_TABLE = "DROP TABLE IF EXISTS " + Util.DATABASE_NAME;
        sqLiteDatabase.execSQL(DROP_PLAYLIST_TABLE, new String[]{Util.PLAYLISTS_TABLE_NAME});

        onCreate(sqLiteDatabase);
    }

    public long insertUser(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.USERNAME, user.getUsername());
        contentValues.put(Util.PASSWORD, user.getPassword());

        long newRowId = db.insert(Util.USERS_TABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }

    public long insertPlaylist(Playlist playlist)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.URL, playlist.getUrl());
        contentValues.put(Util.USER_ID, playlist.getUserId());

        long newRowId = db.insert(Util.PLAYLISTS_TABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }

//    public int removeUser(long id)
//    {
//        SQLiteDatabase db = this.getWritableDatabase();
//
//        String whereArgs[] = {""+id};
//        int count = db.delete(Util.USERS_TABLE_NAME, Util.USER_ID + "=?", whereArgs);
//        return count;
//    }

    // don't need to remove playlist items either...

    public boolean fetchUserUsername(String username)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.USERS_TABLE_NAME, new String[]{Util.USER_ID}, Util.USERNAME + "=?",
                new String[] {username}, null, null, null);

        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return true;
        else
            return false;
    }

    public boolean fetchUser(String username, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.USERS_TABLE_NAME, new String[]{Util.USER_ID}, Util.USERNAME + "=? and " + Util.PASSWORD + "=?",
                new String[] {username, password}, null, null, null, null);

        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return true;
        else
            return false;
    }

    public User getUser(String username)
    {
        User user;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.USERS_TABLE_NAME, new String[]{"*"}, Util.USERNAME + "=?",
                new String[]{username}, null, null, null);

        if (cursor.moveToFirst())
        {
            user = new User();
            user.setUserId(cursor.getInt(0));
            user.setUsername(cursor.getString(1));
            user.setPassword(cursor.getString(2));
            return user;
        }

        return null;
    }

    public List<User> fetchAllUsers(){
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.USERS_TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst())
        {
            do {
                User user = new User();
                user.setUserId(cursor.getInt(0));
                user.setUsername(cursor.getString(1));
                user.setPassword(cursor.getString(2));

                userList.add(user);

            } while (cursor.moveToNext());

        }

        return userList;
    }

    public List<Playlist> fetchAllPlaylists(int userId){
        List<Playlist> playlistList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Util.PLAYLISTS_TABLE_NAME, new String[]{"*"}, Util.USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, null);

        if (cursor.moveToFirst())
        {
            int i = 0;
            do {
                i++;
                Playlist playlist = new Playlist();
                playlist.setPlaylistId(cursor.getInt(0));
//                String url = cursor.getString(1);
//                playlist.set_url(url);
//                playlist.set_userId(cursor.getInt(2));
//                playlist.set_fullUrl("https://www.youtube.com/watch?v=" + url);
                playlist.setUrl(cursor.getString(1));
                playlist.setUserId(cursor.getInt(2));

                playlistList.add(playlist);

            } while (cursor.moveToNext());

        }

        return playlistList;
    }
}
