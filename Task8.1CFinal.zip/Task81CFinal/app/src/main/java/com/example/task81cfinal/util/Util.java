package com.example.task81cfinal.util;

public class Util {

    public static final int DATABASE_VERSION = 4;
    public static final String DATABASE_NAME = "user_db4";

    public static final String USERS_TABLE_NAME = "users";
    public static final String USER_ID = "user_id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    public static final String PLAYLISTS_TABLE_NAME = "playlists";
    public static final String PLAYLIST_ID = "playlist_id";
    public static final String URL = "url";
}
